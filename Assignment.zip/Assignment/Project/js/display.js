function display(aPet) {
//     document.getElementById("pets").innerHTML="";
// //     for(vari=0;i<salon.pets.length;i++){
// //  var aPet=slaon.pets[i];
 var tmp=`
 <div class="pet">
  <h3>${aPet.name}</h3>
  <p> Age: ${aPet.age}</p>
  <p>Gender:${aPet.gender}
  <p>Breed: ${aPet.breed}</p>
  <p>Service: ${aPet.service}</p>
  <p>Owner: ${aPet.owner}</p>
  <p>Phone: ${aPet.phone}</p>
 
 </div> 
   `;
   document.getElementById("pets").innehtml+=tmp;
}
    // }

    // display();

    function displaytable(aPet) {
        var row = `
        <tr>  
        <td>${aPet.name}</td>
        <td>${aPet.breed}</td>
        <td>${aPet.age} </td>
        <td>${aPet.gender} </td>
        <td>${aPet.service}</td>
        <td>${aPet.phone}</td>
        <td>${aPet.owner}</td>
        </tr>
        `;
        document.getElementsByNameID('pet-table').innehtml+=row;
    }




    }