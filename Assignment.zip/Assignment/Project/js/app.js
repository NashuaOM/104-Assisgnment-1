 
 
 
 const salon= {
     siteName:'The Fashion Pet',
     address: {
         city: 'Tijuana',
         street: ' Av. univesidad',
         number: '262-k',
     },

     hours: {
         open:'9:00 am',
         close: '5:00 pm',
     },

    pets: [

        {
            name:"Scooby",
            age:50,
            gender:"Male",
            breed:"Dane",
            service:"shower",
            owner:"shaggy",
            phone:"555-555-5555",
        }
        ,
        {
            name:"Scrapy",
            age:40,
            gender:"Male",
            breed:"Dane",
            service:"Nails cut",
            owner:"shaggy",
            phone:"444-444-4444",
        }
        ,
        {
            name:"Speedy",
            age:60,
            gender:"Male",
            breed:"Mixed",
            service:"Full service",
            owner:"shaggy",
            phone:"777-777-7777",
        }
        ,
        {
            name:"Gold",
            age:43,
            gender:"Female",
            breed:"Mixed",
            service:"Full service",
            owner:"shaggy",
            phone:"333-333-3333",
        }
        ,
        {
            name:"Red",
            age:22,
            gender:"Male",
            breed:"MixePitbull",
            service:"Full service",
            owner:"shaggy",
            phone:"111-111-1111",
        }
    ]


 }

// object destructing
 var {siteName,address:{city,street,number},hours:
 {open,close},pets:{name,age,gender,breed,service,owner,phone}}=salon;
 
 function displayinfo(){
     document.getElementById('footer-info').innerHTML= `
     <p> ${siteName} </p>
     <p> ${street}  ${number}, ${city}</p>
     <p> It opens from ${open} to ${close}
     </p>`;
     }

     displayinfo();
 
 document.getElementById('displayPet').innerHTML=`
 <p> We have five Pets </p> `;
 
 

      var tmp="";
      
      for(var i =0;i<salon.pets.length;i++) {
          tmp+=  `<p> PetName:${i+1} ${salon.name[i]} </p>`;     
        }
        
        document.getElementById('pet-info').innerHTML=tmp;
        
        
        
       
       
   
     




